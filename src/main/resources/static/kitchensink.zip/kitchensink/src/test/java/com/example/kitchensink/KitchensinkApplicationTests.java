package com.example.kitchensink;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KitchensinkApplicationTests {

    @Test
    void contextLoads() {
    }

}
